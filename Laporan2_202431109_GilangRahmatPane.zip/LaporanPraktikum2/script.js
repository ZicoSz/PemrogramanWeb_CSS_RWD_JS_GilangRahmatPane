function togglePenjelasan(id) {
    const para = document.getElementById(id);
    if (para.style.display !== "none") {
        if (confirm("Apakah Anda ingin menyembunyikan penjelasan ini?")) {
            para.style.display = "none";
        }
    } else {
        if (confirm("Apakah Anda ingin menampilkan penjelasan ini?")) {
            para.style.display = "block";
        }
    }
}

function toggleMode() {
    const body = document.body;

    if (body.classList.contains("mode-rapi")) {
        body.classList.remove("mode-rapi");
        body.classList.add("mode-berantakan");
    } else {
        body.classList.remove("mode-berantakan");
        body.classList.add("mode-rapi");
    }
}
